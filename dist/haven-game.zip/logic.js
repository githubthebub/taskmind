export const meta = { game: "Haven", minPlayers: 1, maxPlayers: 1 };

// Haven is a fully client-side wellness experience; the rules module is a
// minimal valid stub so the engine can host it.
export function setup(players) {
  return { player: players[0], startedAt: 0 };
}

export function validateAction(state, playerId, action) {
  return { ok: true };
}

export function applyAction(state, playerId, action) {
  return { ...state };
}

export function isGameOver(state) {
  return { over: false };
}

export function viewFor(state, playerId) {
  return state;
}
